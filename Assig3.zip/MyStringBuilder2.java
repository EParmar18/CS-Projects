// CS 445 Ramirez
// Eshan Parmar

import javax.lang.model.util.ElementScanner6;

// CS 0445 Spring 2019
// Read this class and its comments very carefully to make sure you implement
// the class properly.  The data and public methods in this class are identical
// to those MyStringBuilder, with the exception of the two additional methods
// shown at the end.  You cannot change the data or add any instance
// variables.  However, you may (and will need to) add some private methods.
// No iteration is allowed in this implementation. 

// For more details on the general functionality of most of these methods, 
// see the specifications of the similar method in the StringBuilder class.  
public class MyStringBuilder2
{
	// These are the only three instance variables you are allowed to have.
	// See details of CNode class below.  In other words, you MAY NOT add
	// any additional instance variables to this class.  However, you may
	// use any method variables that you need within individual methods.
	// But remember that you may NOT use any variables of any other
	// linked list class or of the predefined StringBuilder or 
	// or StringBuffer class in any place in your code.  You may only use the
	// String class where it is an argument or return type in a method.
	private CNode firstC;	// reference to front of list.  This reference is necessary
							// to keep track of the list
	private CNode lastC; 	// reference to last node of list.  This reference is
							// necessary to improve the efficiency of the append()
							// method
	private int length;  	// number of characters in the list

	// You may also add any additional private methods that you need to
	// help with your implementation of the public methods.

	// Create a new MyStringBuilder2 initialized with the chars in String s
	public MyStringBuilder2(String s)
	{
		if(s == null || s.length() == 0)
		{
			firstC = null;
			lastC = null;
			length = 0;
		}
		else
		{
			makeBuilder(s, 0);
		}
	}

	private void makeBuilder(String s, int pos)
	{
		// Recursive case – we have not finished going through the String
		if (pos < s.length()-1)
		{
			// Note how this is done – we make the recursive call FIRST, then
			// add the node before it.  In this way the LAST node we add is
			// the front node, and it enables us to avoid having to make a
			// special test for the front node.  However, many of your
			// methods will proceed in the normal front to back way.
			makeBuilder(s, pos+1);
			firstC = new CNode(s.charAt(pos), firstC);
			length++;
		}
		else if (pos == s.length()-1) // Special case for last char in String
		{                             // This is needed since lastC must be set to point to this node
			firstC = new CNode(s.charAt(pos));
			lastC = firstC;
			length = 1;
		} 
		// This case should never be reached, due to the way the
		// constructor is set up.  However, I included it as a safeguard (in case some other method calls this one)
		else
		{  
			length = 0;
			firstC = null;
			lastC = null;
		}
	}

	// Create a new MyStringBuilder2 initialized with the chars in array s
	public MyStringBuilder2(char [] s)
	{
		if(s == null || s.length == 0)
		{
			firstC = null;
			lastC = null;
			length = 0;
		}
		else
		{
			makeBuilder(s, 0);
		}
	}

	private void makeBuilder(char [] s, int pos)
	{
		// Recursive case – we have not finished going through the String
		if (pos < s.length-1)
		{
			// Note how this is done – we make the recursive call FIRST, then
			// add the node before it.  In this way the LAST node we add is
			// the front node, and it enables us to avoid having to make a
			// special test for the front node.  However, many of your
			// methods will proceed in the normal front to back way.
			makeBuilder(s, pos+1);
			firstC = new CNode(s[pos], firstC);
			length++;
		}
		else if (pos == s.length-1) // Special case for last char in String
		{                             // This is needed since lastC must be set to point to this node
			firstC = new CNode(s[pos]);
			lastC = firstC;
			length = 1;
		} 
		// This case should never be reached, due to the way the
		// constructor is set up.  However, I included it as a safeguard (in case some other method calls this one)
		else
		{  
			length = 0;
			firstC = null;
			lastC = null;
		}
	}
	

	// Create a new empty MyStringBuilder2
	public MyStringBuilder2()
	{
		firstC = null;
		lastC = null;
		length = 0;
	}

	// Append MyStringBuilder2 b to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(MyStringBuilder2 b)
	{
		if(length == 0)
		{
			firstC = b.firstC;
			lastC = b.lastC;
			length = b.length;
		}
		else if(b != null && b.length != 0)
		{
			CNode curr = lastC;
			CNode currBNode = b.firstC;
			appendMyStringBuilder(b, curr, currBNode);
		}
		return this;   
	}
	
	private void appendMyStringBuilder(MyStringBuilder2 b, CNode curr, CNode currBNode)
	{
		if(currBNode.next == null)
		{
			CNode newNode = new CNode(currBNode.data);
			curr.next = newNode;
			curr = newNode;
			length++;
			lastC = curr;
		}
		else if(curr != null)
		{
			CNode newNode = new CNode(currBNode.data);
			curr.next = newNode;
			length++;
			appendMyStringBuilder(b, curr.next, currBNode.next);
		}
	}


	// Append String s to the end of the current MyStringBuilder2, and return
	// the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(String s)
	{
		MyStringBuilder2 b = new MyStringBuilder2(s);
		if(length == 0)
		{
			firstC = b.firstC;
			lastC = b.lastC;
			length = b.length;
		}
		else if(s != null && b.length != 0)
		{
			int pos = length;
			CNode curr = lastC;
			MyStringBuilder2 temp = new MyStringBuilder2(s);
			CNode currTempNode = temp.firstC;
			appendString(s, curr, currTempNode);
		}
		return this;
	}

	private void appendString(String s, CNode curr, CNode currTempNode)
	{
		if(currTempNode.next == null)
		{
			CNode newNode = new CNode(currTempNode.data);
			curr.next = newNode;
			curr = newNode;
			length++;
			lastC = curr;
		}
		else if(curr != null)
		{
			CNode newNode = new CNode(currTempNode.data);
			curr.next = newNode;
			length++;
			appendString(s, curr.next, currTempNode.next);
		}
	}

	// Append char array c to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(char [] c)
	{
		MyStringBuilder2 b = new MyStringBuilder2(c);
		if(length == 0)
		{
			firstC = b.firstC;
			lastC = b.lastC;
			length = b.length;
		}
		else if(c != null && b.length != 0)
		{
			int pos = length;
			CNode curr = lastC;
			MyStringBuilder2 temp = new MyStringBuilder2(c);
			CNode currTempNode = temp.firstC;
			appendCharArray(c, curr, currTempNode);
		}
		return this;
	}

	private void appendCharArray(char [] c, CNode curr, CNode currTempNode)
	{
		if(currTempNode.next == null)
		{
			CNode newNode = new CNode(currTempNode.data);
			curr.next = newNode;
			curr = newNode;
			length++;
			lastC = curr;
		}
		else if(curr != null)
		{
			CNode newNode = new CNode(currTempNode.data);
			curr.next = newNode;
			length++;
			appendCharArray(c, curr.next, currTempNode.next);
		}
	}

	// Append char c to the end of the current MyStringBuilder2, and
	// return the current MyStringBuilder2.  Be careful for special cases!
	public MyStringBuilder2 append(char c)
	{
		char [] c1 = new char[] {c};
		MyStringBuilder2 temp = new MyStringBuilder2(c1);
		if(length == 0)
		{
			firstC = temp.firstC;
			lastC = temp.lastC;
			length = temp.length;
		}
		else if(temp != null && temp.length != 0)
		{
			CNode curr = lastC;
			CNode currTempNode = temp.firstC;
			appendCharArray(c1, curr, currTempNode);
		}
		return this;
	}

	// Return the character at location "index" in the current MyStringBuilder2.
	// If index is invalid, throw an IndexOutOfBoundsException.
	public char charAt(int index)
	{
		if(index < 0 || index > length)
		{
			throw new IndexOutOfBoundsException("Index out of Bounds");
		}
		else if(length == 0)
		{
			return ' ';
		}
		else if(index == 0)
		{
			return firstC.data;
		}
		else if(length != 0 && index < length && index > 0)
		{
			CNode curr = firstC;
			curr = getNodeAt(index, curr);
			return curr.data;
		}
		return ' ';
	}

	private CNode getNodeAt(int index, CNode curr) 
	{
		if(index == 0)
		{
			return curr;
		}
		else 
		{
			return getNodeAt(index - 1, curr.next);
		}
	}

	// Delete the characters from index "start" to index "end" - 1 in the
	// current MyStringBuilder2, and return the current MyStringBuilder2.
	// If "start" is invalid or "end" <= "start" do nothing (just return the
	// MyStringBuilder2 as is).  If "end" is past the end of the MyStringBuilder2, 
	// only remove up until the end of the MyStringBuilder2. Be careful for 
	// special cases!
	
	public MyStringBuilder2 delete(int start, int end)
	{
		if(length == 0 || end < 0 || start < 0)
		{
			return this;
		}
		else if(start == 0)
		{
			CNode curr = firstC;
			CNode endN = getNodeAt(end , curr);
			firstC = endN;
			length = length - end;
		}
		else if(end > length)
		{
			CNode curr = firstC;
			CNode startN = null;
			int index = 0;
			deleteString(index, start, length - 1, curr, startN);
			length = length - ((length - 1) - start);
		}
		else if(length != 0)
		{
			CNode curr = firstC;
			CNode startN = null;
			int index = 0;
			deleteString(index, start, end, curr, startN);
			length = length - ((end-1) - start);
		}
		return this;
	}

	private void deleteString(int index, int start, int end, CNode curr, CNode startN)
	{	
		if(index == start - 1)
		{
			startN = curr;
			deleteString(index+1, start, end, curr.next, startN);
		}
		else if(index == end)
		{
			startN.next = curr;
		}
		else
		{
			deleteString(index+1, start, end, curr.next, startN);
		}		
	}
	// Delete the character at location "index" from the current
	// MyStringBuilder2 and return the current MyStringBuilder2.  If "index" is
	// invalid, do nothing (just return the MyStringBuilder2 as is).
	// Be careful for special cases!
	
	public MyStringBuilder2 deleteCharAt(int index)
	{
		if(index < 0 || index > length || length == 0)
		{
			return this;
		}
		else if(index == 0)
		{
			CNode curr = firstC;
			curr = curr.next;
			firstC = curr;
			length--;
		}
		else if(index == length)
		{
			CNode curr = firstC;
			CNode temp = getNodeAt(length -1,curr);
			temp = lastC;
		}
		else if(index > 0 && index < length)
		{
			CNode currNode = firstC;
			CNode befNode = getNodeAt(index - 1, currNode);
			CNode aftNode = getNodeAt(index + 1, currNode);
			befNode.next = aftNode;
			length--;
		}
		return this;
	}
	
	// Find and return the index within the current MyStringBuilder2 where
	// String str first matches a sequence of characters within the current
	// MyStringBuilder2.  If str does not match any sequence of characters
	// within the current MyStringBuilder2, return -1.  Think carefully about
	// what you need to do for this method before implementing it.
	
	public int indexOf(String str)
	{
		if(str == null)
		{
			return -1;
		}
		else
		{
			MyStringBuilder2 s = new MyStringBuilder2(str);
			int index = 0;
			int length = str.length();
			int match = 0;
			CNode curr = firstC;
			CNode otherCurr = s.firstC;
			int[] val = new int[1];
			val[0] = -1;
			int x = 0;
			x = indexOfString(index, match, length, curr, otherCurr, s, val);
			//System.out.println(x);
			return x;
		}
	}
	private int indexOfString(int index, int match, int length, CNode curr, CNode otherCurr, MyStringBuilder2 s, int[] val)
	{
		if(match == length)
		{
			//System.out.println("1");
			
			val[0] = (index - length);
			//System.out.println("VAL1: " + val[0]);
			return val[0];
		}
		else if(curr != null)
		{
			if(curr.data == otherCurr.data)
			{
				//System.out.println("2");
				indexOfString(index + 1, match + 1, length, curr.next, otherCurr.next, s, val);
			}
			if(curr.data != otherCurr.data)
			{
				//System.out.println("3");
				otherCurr = s.firstC;
				match = 0;
				indexOfString(index+1, match, length, curr.next, otherCurr, s, val);
			}
		}
		else if(curr == null)
		{
			//System.out.println("VAL3: " + val[0]);
			return val[0];
		}	
		return val[0];
	}
	
	// Insert String str into the current MyStringBuilder2 starting at index
	// "offset" and return the current MyStringBuilder2.  if "offset" == 
	// length, this is the same as append.  If "offset" is invalid
	// do nothing.
	
	public MyStringBuilder2 insert(int offset, String str)
	{
		if(offset < 0 || offset > length || length == 0)
		{
			return this;
		}
		else if(offset == length)
		{
			append(str);
			length += str.length();
			return this;
		}
		else if(offset == 0)
		{
			MyStringBuilder2 temp2 = new MyStringBuilder2(str);
			temp2.lastC.next = firstC;
			firstC = temp2.firstC;
			length += str.length();
		}
		else if(offset < length && offset > 0)
		{
			CNode curr = firstC;
			CNode startN = getNodeAt(offset - 1, curr);
			System.out.println(startN.data);
			CNode aftN = startN.next;
			MyStringBuilder2 temp = new MyStringBuilder2(str);
			startN.next = temp.firstC;
			temp.lastC.next = aftN;
			length = length + str.length();
		}
		return this;
	}
	
	// Insert character c into the current MyStringBuilder2 at index
	// "offset" and return the current MyStringBuilder2.  If "offset" ==
	// length, this is the same as append.  If "offset" is invalid, 
	// do nothing.
	public MyStringBuilder2 insert(int offset, char c)
	{
		if(offset < 0 || offset > length || length == 0)
		{
			return this;
		}
		else if(offset == length)
		{
			append(c);
			length++;
			return this;
		}
		else if(offset == 0)
		{
			char [] c1 = new char[] {c};
			MyStringBuilder2 temp = new MyStringBuilder2(c1);
			temp.lastC.next = firstC;
			firstC = temp.firstC;
			length++;
		}
		else if(offset < length && offset > 0)
		{
			char [] c1 = new char[] {c};
			CNode curr = lastC;
			MyStringBuilder2 temp = new MyStringBuilder2(c1);
			CNode currTempNode = temp.firstC;
			appendCharArray(c1, curr, currTempNode);
			length++;
		}
		return this;
	}

	// Insert char array c into the current MyStringBuilder2 starting at index
	// index "offset" and return the current MyStringBuilder2.  If "offset" is
	// invalid, do nothing.
	public MyStringBuilder2 insert(int offset, char [] c)
	{
		if(offset < 0 || offset > length || length == 0)
		{
			return this;
		}
		else if(offset == length)
		{
			append(c);
			length += c.length;
			return this;
		}
		else if(offset == 0)
		{
			MyStringBuilder2 temp = new MyStringBuilder2(c);
			temp.lastC.next = firstC;
			firstC = temp.firstC;
			length += c.length;
		}
		else if(offset < length && offset > 0)
		{
			CNode curr = firstC;
			CNode startN = getNodeAt(offset, curr);
			System.out.println(startN.data);
			CNode aftN = startN.next;
			MyStringBuilder2 temp = new MyStringBuilder2(c);
			startN.next = temp.firstC;
			temp.lastC.next = aftN;

		}
		return this;
	}
	
	// Return the length of the current MyStringBuilder2
	public int length()
	{
		return length;
	}
	
	// Delete the substring from "start" to "end" - 1 in the current
	// MyStringBuilder2, then insert String "str" into the current
	// MyStringBuilder2 starting at index "start", then return the current
	// MyStringBuilder2.  If "start" is invalid or "end" <= "start", do nothing.
	// If "end" is past the end of the MyStringBuilder2, only delete until the
	// end of the MyStringBuilder2, then insert.  This method should be done
	// as efficiently as possible.  In particular, you may NOT simply call
	// the delete() method followed by the insert() method, since that will
	// require an extra traversal of the linked list.
	
	public MyStringBuilder2 replace(int start, int end, String str)
	{
		if(start < 0 || start > length || end <= start || end < 0)
		{
			return this;
		}
		else if(length == 0)
		{
			append(str);
		}
		else if(start == 0)
		{
			MyStringBuilder2 s = new MyStringBuilder2(str);
			CNode curr = firstC;
			CNode startN = firstC.next;
			int index = 0;
			replaceString(index, start, end, curr, startN, s);
			length = length + str.length() - (end - start);
		}
		else if(end > length)
		{
			MyStringBuilder2 s = new MyStringBuilder2(str);
			CNode curr = firstC;
			CNode startN = null;
			int index = 0;
			replaceString(index, start, length - 1, curr, startN, s);
			length = length + str.length() - ((length - 1) - start);
		}
		else
		{
			MyStringBuilder2 s = new MyStringBuilder2(str);
			CNode curr = firstC;
			CNode startN = null;
			int index = 0;
			replaceString(index, start, end, curr, startN, s);
			length = length + str.length() - (end - start);
		}
		return this;
	}

	private void replaceString(int index, int start, int end, CNode curr, CNode startN, MyStringBuilder2 s)
	{	
		if(index == start - 1)
		{
			startN = curr;
			replaceString(index+1, start, end, curr.next, startN, s);
		}
		else if(index == end)
		{
			CNode temp = curr;
			startN.next = s.firstC;
			s.lastC.next = temp;
		}
		else
		{
			replaceString(index+1, start, end, curr.next, startN, s);
		}	
	}
	// Reverse the characters in the current MyStringBuilder2 and then
	// return the current MyStringBuilder2.
	public MyStringBuilder2 reverse()
	{
		if(length == 0)
		{
			return null;
		}
		else
		{
			CNode curr = firstC;
			CNode befNode = null;
			CNode aftNode = null;
			int pos = 0;
			reverseBuilder(pos, curr, befNode, aftNode);
		}
		return this;
	}

	private void reverseBuilder(int pos, CNode curr, CNode befNode, CNode aftNode)
	{
		if(curr == null)
		{
			firstC = befNode;
		}
		else if(curr != null)
		{
			aftNode = curr.next;
			curr.next = befNode;
			befNode = curr;
			curr = aftNode;
			reverseBuilder(pos + 1, curr, befNode, aftNode);
		}
	}
	
	// Return as a String the substring of characters from index "start" to
	// index "end" - 1 within the current MyStringBuilder2
	
	public String substring(int start, int end)
	{
		if(length == 0)
		{
			return null;
		}
		else if(start < 0 || end > length || end < start)
		{
			return null;
		}
		else if(start == 0)
		{
			char [] c = new char[end - start + 1];
			int index = 0;
			int pos = 0;
			CNode curr = firstC;
			recSubString(index, 0, end - 1, curr, pos, c);
			return (new String(c));
		}
		else if(end > length)
		{
			char [] c = new char[end - start];
			int index = 0;
			int pos = 0;
			CNode curr = firstC;
			recSubString(index, start, length - 1, curr, pos, c);
			return (new String(c));
		}
		else if(start > 0 && end < length)
		{
			char [] c = new char[end - start + 1];
			int index = 0;
			int pos = 0;
			CNode curr = firstC;
			recSubString(index, start, end - 1, curr, pos, c);
			return (new String(c));
		}
		else
		{
			return null;
		}
	}

	private void recSubString(int index, int start, int end, CNode curr, int pos, char[] c)
	{
		if(curr != null)
		{

			if(index >= start && index <= end)
			{
				c[pos] = curr.data;
				recSubString(index + 1, start, end, curr.next, pos+1, c);
			}
			else
			{
				recSubString(index + 1, start, end, curr.next, pos, c);
			}
		}
	}


	
	// Return the entire contents of the current MyStringBuilder2 as a String
	public String toString()
	{
      char [] c = new char[length];
      getString(c, 0, firstC);
      return (new String(c));
	}

	private void getString(char [] c, int pos, CNode curr)
	{
      if (curr != null)
      {
            c[pos] = curr.data;
            getString(c, pos+1, curr.next);
      }
	}



	// Find and return the index within the current MyStringBuilder2 where
	// String str LAST matches a sequence of characters within the current
	// MyStringBuilder2.  If str does not match any sequence of characters
	// within the current MyStringBuilder2, return -1.  Think carefully about
	// what you need to do for this method before implementing it.  For some
	// help with this see the Assignment 3 specifications
	
	public int lastIndexOf(String str)
	{
		if(str == null)
		{
			return -1;
		}
		else
		{
			CNode curr = firstC;
			CNode startN = null;
			int match = 0;
			int length = str.length();
			int index = 0;
			int max = 0;
			MyStringBuilder2 s = new MyStringBuilder2(str);
			CNode otherCurr = s.firstC;
			int [] val = new int[1];
			val[0] = -1;
			int x = recLastIndexOf(index, match, length, curr, otherCurr, s, str, val, max);
			return x;
		}
	}

	private int recLastIndexOf(int index, int match, int length, CNode curr, CNode otherCurr, MyStringBuilder2 s, String str, int[] val, int max)
	{
		if(curr != null)
		{
			recLastIndexOf(index + 1, match, length, curr.next, otherCurr, s,str, val,max);
		}
		if(indexOfString(index,0, str.length(), curr, otherCurr, s, val) != -1)
		{
			System.out.println( indexOfString(index,0, str.length(), curr, otherCurr, s, val));
			return indexOfString(index,0, str.length(), curr, otherCurr, s, val);
		}
		return val[0];
	}
	/*
	// Find and return an array of MyStringBuilder2, where each MyStringBuilder2
	// in the return array corresponds to a part of the match of the array of
	// patterns in the argument.  If the overall match does not succeed, return
	// null.  For much more detail on the requirements of this method, see the
	// Assignment 3 specifications.
	public MyStringBuilder2 [] regMatch(String [] pats)
	{
		int length = pats.length;
		int pos = 0;

	}

	private boolean recRegMatch(String [] pats, int index, CNode curr, int match, int length, int pos)
	{
		if(curr == null)
		{
			return false;
		}
		else if()
	}
	*/
	// You must use this inner class exactly as specified below.  Note that
	// since it is an inner class, the MyStringBuilder2 class MAY access the
	// data and next fields directly.
	private class CNode
	{
		private char data;
		private CNode next;

		public CNode(char c)
		{
			data = c;
			next = null;
		}

		public CNode(char c, CNode n)
		{
			data = c;
			next = n;
		}
	}
}

