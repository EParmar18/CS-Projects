#include <stdio.h>
#include "csapp.h"
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400


/* You won't lose style points for including these long lines in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *accept_hdr = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n";
static const char *accept_encoding_hdr = "Accept-Encoding: gzip, deflate\r\n";

#include "csapp.h"

void doit(int fd);
void read_requesthdrs(rio_t *rp);
int parse_uri(char *uri, char *hostname, int *port);
void clienterror(int fd, char *cause, char *errnum, 
		         char *shortmsg, char *longmsg);
int powerten(int i);
void proxy_init(void);
void init_cache(void);
void *thread(void *vargp);
static void update_use(int *cache_use, int current, int len);
static int load_cache(char *tag, char *response);

static void save_cache(char *tag, char *response);
static void request_hdr(char *buf, char *buf2ser, char *hostname);

// global variables
sem_t mutex;
static int set_num, line_num;

struct cache
{
    struct cache_set *set;
};

static struct cache cache;

struct cache_line
{
    int valid;
    char *tag;
    char *block;
};

struct cache_set
{
    struct cache_line *line;
    int *use;
};


int main(int argc, char **argv) 
{
    signal(SIGPIPE, SIG_IGN); // Required for the function to operate

    int listenfd;
    int *connfd;
		// Declares the initial variables used inside of the function
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_in clientaddr;
    pthread_t tid;

    /* Creates a check for any and all command line arguments */
    if (argc != 2) {
	    fprintf(stderr, "usage: %s <port>\n", argv[0]);
	    exit(1);
    }

    proxy_init();
    listenfd = Open_listenfd(argv[1]);
    while (1) {
	    clientlen = sizeof(clientaddr);
        connfd = malloc(sizeof(int));
	    *connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); 
        printf("Accepted connection from (%s, %s)\n", hostname, port);
//#include <string.h>
        pthread_create(&tid, NULL, thread, connfd);
    }
    return 0;
}

void proxy_init()
{
	// Initializes everything for the proxy in order to work 
    sem_init(&mutex, 0, 1);
    set_num = 1;
    line_num = 10;
    init_cache();
}

// Initializes the chache required for the extra credit portion
void init_cache()
{
	// Initializes the loop variables needed to go through the cache
    int x, y;
    cache.set = malloc(sizeof (struct cache_set) * set_num);
    for (x = 0; x < set_num; x++)
    {
        cache.set[x].line = malloc(sizeof(struct cache_line) * line_num);
        cache.set[x].use = malloc(sizeof(int) * line_num);
       for (y = 0; y < line_num; y++)
       {
           cache.set[x].use[y] = y;
           cache.set[x].line[y].valid = 0;
           cache.set[x].line[y].tag = malloc(MAXLINE);
           cache.set[x].line[y].block = malloc(MAX_OBJECT_SIZE);
       } 
    }
}

// Save the cache and response
static void save_cache(char *tag, char *response)
{
    int index, eviction;
    index = 0;
    eviction = cache.set[index].use[line_num - 1];
    strcpy(cache.set[index].line[eviction].tag, tag);
    strcpy(cache.set[index].line[eviction].block, response);
//#include <string.h>
    if (cache.set[index].line[eviction].valid == 0) {
        cache.set[index].line[eviction].valid = 1;
    }
    update_use(cache.set[index].use, eviction, line_num);;
}


// Checks the recent uses of the cache and the current uses
static void update_use(int *cacheu, int c, int len)
{
    int x, y;
    for(x = 0; x < len; x++)
    {
        if(cacheu[x] == c) {
             break;
        }
    }
    for(y = x; y > 0; y--)
    {
        cacheu[y] = cacheu[y - 1];
    }                               
//#include <string.h>
    cacheu[0] = c;
}

// Loads teh current cache and performs the necessary operations needed
static int load_cache(char *tag, char *response) 
{
    int index, x;
    index = 0;
    for (x = 0; x < line_num; x++) {
        if(cache.set[index].line[x].valid == 1 && 
          (strcmp(cache.set[index].line[x].tag, tag) == 0))
        {
            P(&mutex);
            update_use(cache.set[index].use, x, line_num);
            V(&mutex);
            strcpy(response, cache.set[index].line[x].block);
            break;
        }
    }
    if (x == line_num) {
        return 0;
    }
    else {
        return 1;
    }
}


/*
 * doit - handle one HTTP request/response transaction
 */

/* $begin doit */
void doit(int fd) 
{
    int serverfd, len, object_len;

    int *port;
    char port2[10];
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char cache_buf[MAX_OBJECT_SIZE];
    char filename[MAXLINE];         
    char hostname[MAXBUF];          
    char buf2ser[MAXLINE];          
    char ser_response[MAXLINE];     
    rio_t rio, rio_ser;             
                                    
    port = malloc(sizeof(int));
    *port = 80;                      

    memset(buf2ser, 0, sizeof(buf2ser)); 
    memset(filename, 0, sizeof(filename)); 
    memset(hostname, 0, sizeof(hostname)); 
    memset(ser_response, 0, sizeof(ser_response));
    memset(uri, 0, sizeof(uri));
    memset(method, 0, sizeof(method));
    memset(buf, 0, sizeof(buf));
    memset(version, 0, sizeof(version));
    memset(cache_buf, 0, sizeof(cache_buf)); 

    Rio_readinitb(&rio, fd);
    if (!Rio_readlineb(&rio, buf, MAXLINE))  
        return;
    printf("request from client: %s\n", buf);

    sscanf(buf, "%s %s %s", method, uri, version);       
    
    if (!strcasecmp(version, "HTTP/1.1")) {
        strcpy(version, "HTTP/1.0");
    }

    if (strcasecmp(method, "GET")) {     
        clienterror(fd, method, "501", "Not Implemented",
                    "This proxy does not implement this method");
        return;
    }               
    read_requesthdrs(&rio);

    parse_uri(uri, hostname, port);       
    strcpy(filename, uri);
    sprintf(buf2ser, "%s %s %s\r\n", method, filename, version);
    printf("proxy to server: %s\n", buf2ser);

    request_hdr(buf, buf2ser, hostname);
    
    if (load_cache(uri, cache_buf) == 1) {
        printf("Hit!\n");
        if (rio_writen(fd, cache_buf, sizeof(cache_buf)) < 0) {
            fprintf(stderr, "Error: cache load!\n");
            return;
        }
        memset(cache_buf, 0, sizeof(cache_buf));
    }
    else {   
        sprintf(port2, "%d", *port);
        if((serverfd = open_clientfd(hostname, port2)) < 0)
        {
            fprintf(stderr, "open server fd error\n");
            return;
        }

        Rio_readinitb(&rio_ser, serverfd);

        Rio_writen(serverfd, buf2ser, strlen(buf2ser));

        memset(cache_buf, 0, sizeof(cache_buf));
        object_len = 0;

        while ((len = rio_readnb(&rio_ser, ser_response, 
                sizeof(ser_response))) > 0) {

            Rio_writen(fd, ser_response, len);

            strcat(cache_buf, ser_response);
            object_len += len;
            memset(ser_response, 0, sizeof(ser_response)); 
        }    
        if (object_len <= MAX_OBJECT_SIZE)
        {
            P(&mutex);
            save_cache(uri, cache_buf);
            V(&mutex);
        }
        close(serverfd);
    }
}
static void request_hdr(char *buf, char *buf2ser, char *hostname)
{
    if(strcmp(buf, "Host"))
    {
          strcat(buf2ser, "Host: ");
          strcat(buf2ser, hostname);
          strcat(buf2ser, "\r\n");
    }
    if(strcmp(buf, "Accept:")) {
        strcat(buf2ser, accept_hdr);
    }
    if(strcmp(buf, "Accept-Encoding:")) {
        strcat(buf2ser, accept_encoding_hdr);
    }
    if(strcmp(buf, "User-Agent:")) {
        strcat(buf2ser, user_agent_hdr);
    }
    if(strcmp(buf, "Proxy-Connection:")) {
        strcat(buf2ser, "Proxy-Connection: close\r\n");
    }
    if(strcmp(buf, "Connection:")) {
        strcat(buf2ser, "Connection: close\r\n");
    }
    memset(buf, 0, sizeof(buf));
    strcat(buf2ser, "\r\n");
}

void *thread(void *vargp)
{
    int connfd = *((int *)vargp);
    pthread_detach(pthread_self());
    free(vargp);
    doit(connfd);
    close(connfd);
    return NULL;
}

void read_requesthdrs(rio_t *rp) 
{
    char buf[MAXLINE];

    Rio_readlineb(rp, buf, MAXLINE);
    printf("%s", buf);
    while(strcmp(buf, "\r\n")) {      
	Rio_readlineb(rp, buf, MAXLINE);
	printf("%s", buf);
    }
    return;
}

int parse_uri(char *uri, char *hostname, int *port) 
{

    char tmp[MAXLINE];          
    char *buf;                  
    char *endbuf;               
    int port_tmp[10];
    int i, j;                   
    char num[2];                

    buf = tmp;
    for (i = 0; i < 10; i++) {
        port_tmp[i] = 0;
    }
    (void) strncpy(buf, uri, MAXLINE);
    endbuf = buf + strlen(buf);
    buf += 7;                   
    while (buf < endbuf) {
    // take host name out
        if (buf >= endbuf) {
            strcpy(uri, "");
            strcat(hostname, " ");
            break;
        }
        if (*buf == ':') {  // if port number exists
            buf++;
            *port = 0;
            i = 0;
            while (*buf != '/') {
                num[0] = *buf;
                num[1] = '\0';
                port_tmp[i] = atoi(num);
                buf++;
                i++;
            }
            j = 0;
            while (i > 0) {
                *port += port_tmp[j] * powerten(i - 1);
                j++;
                i--;
            }
        }
        if (*buf != '/') {

            sprintf(hostname, "%s%c", hostname, *buf);
        }
        else { // host name done
            strcat(hostname, "\0");
            strcpy(uri, buf);
            break;
        }
        buf++;
    }
    return 1;
}
int powerten(int i) {
    int num = 1;
    while (i > 0) {
        num *= 10;
        i--;
    }
    return num;
}

void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    Rio_writen(fd, buf, strlen(buf));
    Rio_writen(fd, body, strlen(body));
}
/* $end clienterror */
