import javax.lang.model.util.ElementScanner6;

// CS 0445 Spring 2019
// Eshan Parmar
// Read this class and its comments very carefully to make sure you implement
// the class properly.  Note the items that are required and that cannot be
// altered!  Generally speaking you will implement your MyStringBuilder using
// a singly linked list of nodes.  See more comments below on the specific
// requirements for the class.

// For more details on the general functionality of most of these methods, 
// see the specifications of the similar method in the StringBuilder class.  
public class MyStringBuilder
{
	// These are the only three instance variables you are allowed to have.
	// See details of CNode class below.  In other words, you MAY NOT add
	// any additional instance variables to this class.  However, you may
	// use any method variables that you need within individual methods.
	// But remember that you may NOT use any variables of any other
	// linked list class or of the predefined StringBuilder or 
	// or StringBuffer class in any place in your code.  You may only use the
	// String class where it is an argument or return type in a method.
	private CNode firstC;	// reference to front of list.  This reference is necessary
							// to keep track of the list
	private CNode lastC; 	// reference to last node of list.  This reference is
							// necessary to improve the efficiency of the append()
							// method
	private int length;  	// number of characters in the list

	// You may also add any additional private methods that you need to
	// help with your implementation of the public methods.

	// Create a new MyStringBuilder initialized with the chars in String s
	public MyStringBuilder(String s)
	{
        if(s == null || s.length() == 0)
        {
            firstC = null;
            lastC = null;
            length = 0;
        }
        else
        {
            firstC = new CNode(s.charAt(0));
            length = 1;
            CNode currNode = firstC;
            CNode newNode;
            for(int x = 1; x < s.length(); x++)
            {
                newNode = new CNode(s.charAt(x));
                currNode.next = newNode;
                currNode = newNode;
                length++;
            }
            lastC = currNode;
        }
	}

	// Create a new MyStringBuilder initialized with the chars in array s
	public MyStringBuilder(char [] s)
	{
        if(s.length == 0 || s == null)
        {
            firstC = null;
            lastC = null;
            length = 0;
        }
        else
        {
            firstC = new CNode(s[0]);
            length = 1;
            CNode currNode = firstC;

            for(int x = 1; x < s.length; x++)
            {
                CNode newNode = new CNode(s[x]);
                currNode.next = newNode;
                currNode = newNode;
                length++;
            }
            lastC = currNode;
        }
	}

	// Create a new empty MyStringBuilder
	public MyStringBuilder()
	{
        firstC = null;
        lastC = null;
        length = 0;
	}
    
	// Append MyStringBuilder b to the end of the current MyStringBuilder, and
	// return the current MyStringBuilder.  Be careful for special cases!
	public MyStringBuilder append(MyStringBuilder b)
	{
        CNode newNode;
        CNode currNode;

        if(length == 0)
        {
            newNode = new CNode(b.firstC.data, b.firstC.next);
            firstC = newNode;
            currNode = firstC;
            for(int x = 1; x <= b.length; x++)
            {
                newNode = newNode.next;
                currNode.next = newNode;
                currNode = newNode;
                length++;
            }
            lastC = currNode;
        }
        else
        {   
            currNode = lastC;
            newNode = new CNode(b.firstC.data, b.firstC.next);
            for(int x = 1; x <= b.length; x++)
            {
                currNode.next = newNode;
                currNode = newNode;
                newNode = newNode.next; 
                length++;
            }
            lastC = currNode;
        }
        return this;
	}

    
	// Append String s to the end of the current MyStringBuilder, and return
	// the current MyStringBuilder.  Be careful for special cases!
	public MyStringBuilder append(String s)
	{
        MyStringBuilder newString = new MyStringBuilder(s);

        CNode newNode;
        CNode currNode;

        if(length == 0)
        {
            newNode = new CNode(newString.firstC.data, newString.firstC.next);
            firstC = newNode;
            currNode = firstC;
            for(int x = 1; x <= newString.length; x++)
            {
                newNode = newNode.next;
                currNode.next = newNode;
                currNode = newNode;
                length++;
            }
            lastC = currNode;
        }
        else
        {   
            currNode = lastC;
            newNode = new CNode(newString.firstC.data, newString.firstC.next);
            for(int x = 1; x <= newString.length; x++)
            {
                currNode.next = newNode;
                currNode = newNode;
                newNode = newNode.next; 
                length++;
            }
            lastC = currNode;
        }
        return this;
	}

	// Append char array c to the end of the current MyStringBuilder, and
	// return the current MyStringBuilder.  Be careful for special cases!
	public MyStringBuilder append(char [] c)
	{
        MyStringBuilder newString = new MyStringBuilder(c);

        CNode newNode;
        CNode currNode;

        if(length == 0)
        {
            newNode = new CNode(newString.firstC.data, newString.firstC.next);
            firstC = newNode;
            currNode = firstC;
            for(int x = 1; x <= newString.length(); x++)
            {
                currNode = newNode;
                newNode = newNode.next;
                currNode.next = newNode;
                currNode = newNode;
                length++;
            }
            lastC = currNode;
        }
        else
        {   
            currNode = lastC;
            newNode = new CNode(newString.firstC.data, newString.firstC.next);
            for(int x = 1; x <= newString.length; x++)
            {
                currNode.next = newNode;
                currNode = newNode;
                newNode = newNode.next; 
                length++;
            }
            lastC = currNode;
        }
        return this;
	}

	// Append char c to the end of the current MyStringBuilder, and
	// return the current MyStringBuilder.  Be careful for special cases!
	public MyStringBuilder append(char c)
	{
        CNode newNode = new CNode(c);
        if(length == 0)
        {
            firstC = newNode;
            lastC = newNode;
            length++;
        }
        else
        {
            CNode currNode = lastC;
            currNode.next = newNode;
            currNode = newNode;
            length++;
            lastC = currNode;
        }
        
        return this;
	}
    
	// Return the character at location "index" in the current MyStringBuilder.
	// If index is invalid, throw an IndexOutOfBoundsException.
	public char charAt(int index)
	{
        CNode currNode = firstC;
        if(index > length || index < 0)
        {
            throw new IndexOutOfBoundsException("Index is out of bounds");
        }
        else
        {
            for(int x = 1; x <= index; x++)
            {
                currNode = currNode.next;
            }
        }
        return currNode.data;
	}

	// Delete the characters from index "start" to index "end" - 1 in the
	// current MyStringBuilder, and return the current MyStringBuilder.
	// If "start" is invalid or "end" <= "start" do nothing (just return the
	// MyStringBuilder as is).  If "end" is past the end of the MyStringBuilder, 
	// only remove up until the end of the MyStringBuilder. Be careful for 
    // special cases!
    
	public MyStringBuilder delete(int start, int end)
	{
        CNode currNode = firstC;
        CNode befNode = firstC;

        if(start < 0 || start > length || end <= start || end < 0)
        {
            return this;
        }
        else if(length == 0)
        {
            return this;
        }
        else
        {
            if(start == 0)
            {
                for(int x = 1; x <= end -1; x++)
                {
                    currNode = currNode.next;
                }
                firstC = currNode.next;
                length = length - end;
            }
            else
            {
                for(int x = 0; x < start; x++)
                {
                    currNode = currNode.next;
                    if(x == (start - 2))
                    {
                        befNode = currNode;
                    }
                }
                if(end > length)
                {
                    for(int y = start; y < length -1; y++)
                    {    
                    currNode = currNode.next;
                    }

                    befNode.next = currNode;
                    length = length - ((length - 1) - start);
                    lastC = currNode;
                }
                else
                {
                    for(int y = start; y <= end -1; y++)
                    {    
                        currNode = currNode.next;
                    }

                    befNode.next = currNode;
                    length = length - ((end - 1) - start);
                } 
            }
        }
        return this;
	}
    
	// Delete the character at location "index" from the current
	// MyStringBuilder and return the current MyStringBuilder.  If "index" is
	// invalid, do nothing (just return the MyStringBuilder as is).
    // Be careful for special cases!
    
	public MyStringBuilder deleteCharAt(int index)
	{
        if(index > length || index < 0)
        {
            return this;
        }
        else if(index == 0)
        {
            CNode currNode = firstC.next;
            firstC = currNode;
            length--;
            return this;
        }
        else
        {
            if(length == 0)
            {
                return this;
            }
        
            CNode currNode = firstC;
            CNode befNode = firstC;
            CNode aftNode;
            for(int x = 1; x <= index; x++)
            {
                currNode = currNode.next;
                if(x == (index - 1))
                {
                    befNode = currNode;
                }
            }
            if(index == length)
            {
                befNode.next = null;
                lastC = befNode;
                length--;
            }
            else
            {
                aftNode = currNode.next;
                befNode.next = aftNode;
                length--;
            }
        }
        return this;
    }
    

	// Find and return the index within the current MyStringBuilder where
	// String str first matches a sequence of characters within the current
	// MyStringBuilder.  If str does not match any sequence of characters
	// within the current MyStringBuilder, return -1.  Think carefully about
    // what you need to do for this method before implementing it.
    
	public int indexOf(String str)
	{
        CNode currNode = firstC;
        int count = 0;
        for(int x = 1; x <= length; x++)
        {   
            if(currNode.data == (str.charAt(0)))
            {
                count++;
                CNode test = currNode;
                test = test.next;
                for(int i = 1; i < str.length(); i++)
                {
                    if(test.data == str.charAt(i))
                    {
                        count++;
                    }
                    if(test.next != null)
                    {
                        test = test.next;
                    }
                }
                if(count == str.length())
                {
                    return (x - 1);
                }
                else
                {
                    count = 0;
                }
            }
            currNode = currNode.next;
        }
        return -1;
    }
    

	// Insert String str into the current MyStringBuilder starting at index
	// "offset" and return the current MyStringBuilder.  if "offset" == 
	// length, this is the same as append.  If "offset" is invalid
    // do nothing.
    
	public MyStringBuilder insert(int offset, String str)
	{
        if(offset < 0 || offset > length)
        {
            return this;
        }
        else if(offset == length)
        {
            return append(str);
        }
        else if(offset == 0)
        {
            MyStringBuilder s = new MyStringBuilder(str);
            CNode aftNode = firstC;
            CNode otherCurr = s.firstC;
            firstC = otherCurr;
            otherCurr = s.lastC;
            otherCurr.next = aftNode;
            length+= s.length();
        }
        else
        {
            CNode currNode = firstC;
            CNode aftNode;
            MyStringBuilder s = new MyStringBuilder(str);
            CNode otherCurr = s.firstC; 
            for(int x = 1; x < offset; x++)
            {
                currNode = currNode.next;
            }
            aftNode = currNode.next;
            for(int y = 1; y <= s.length(); y++)
            {
                currNode.next = otherCurr;
                currNode = otherCurr;
                otherCurr = otherCurr.next;
            }
            currNode.next = aftNode;
            length+=s.length();
        }
        return this;
    }
	// Insert character c into the current MyStringBuilder at index
	// "offset" and return the current MyStringBuilder.  If "offset" ==
	// length, this is the same as append.  If "offset" is invalid, 
	// do nothing.
	public MyStringBuilder insert(int offset, char c)
    {
        if(offset < 0 || offset > length)
        {
            return this;
        }   
        else if(offset == length)
        {
            return append(c);
        }
        else if(offset == 0)
        {
            CNode newChar = new CNode(c);
            CNode aftNode = firstC;
            firstC = newChar;
            firstC.next = aftNode;

        } 
        else  
        {
            CNode currNode = firstC;
            CNode newChar = new CNode(c);
            CNode aftNode;
            CNode befNode = firstC;
            for(int x = 1; x < offset; x++)
            {
                currNode = currNode.next;
            }
            aftNode = currNode.next;
            currNode.next = newChar;
            newChar.next = aftNode;
        }     
        return this; 
	}

	// Insert char array c into the current MyStringBuilder starting at index
	// index "offset" and return the current MyStringBuilder.  If "offset" is
    // invalid, do nothing.
    
	public MyStringBuilder insert(int offset, char [] c)
	{
        if(offset < 0 || offset > length)
        {
            return this;
        }
        else if(offset == length)
        {
            return append(c);
        }
        else if(offset == 0)
        {
            MyStringBuilder s = new MyStringBuilder(c);
            CNode aftNode = firstC;
            CNode otherCurr = s.firstC;
            firstC = otherCurr;
            otherCurr = s.lastC;
            otherCurr.next = aftNode;
            length+= s.length();
        }
        else
        {
            CNode currNode = firstC;
            CNode aftNode;
            MyStringBuilder s = new MyStringBuilder(c);
            CNode otherCurr = s.firstC; 
            for(int x = 1; x < offset; x++)
            {
                currNode = currNode.next;
            }
            aftNode = currNode.next;
            for(int y = 1; y <= s.length(); y++)
            {
                currNode.next = otherCurr;
                currNode = otherCurr;
                otherCurr = otherCurr.next;
            }
            currNode.next = aftNode;
            length+=s.length();
        }
        return this;
	}
    
    // Return the length of the current MyStringBuilder
    
	public int length()
	{
        return length;
	}
    
	// Delete the substring from "start" to "end" - 1 in the current
	// MyStringBuilder, then insert String "str" into the current
	// MyStringBuilder starting at index "start", then return the current
	// MyStringBuilder.  If "start" is invalid or "end" <= "start", do nothing.
	// If "end" is past the end of the MyStringBuilder, only delete until the
	// end of the MyStringBuilder, then insert.  This method should be done
	// as efficiently as possible.  In particular, you may NOT simply call
	// the delete() method followed by the insert() method, since that will
    // require an extra traversal of the linked list
    
	public MyStringBuilder replace(int start, int end, String str)
	{
        CNode currNode = firstC;
        CNode befNode = firstC;
        MyStringBuilder s = new MyStringBuilder(str);
        CNode aftNode = firstC;
        CNode otherCurr = s.firstC; 

        if(start < 0 || start > length || end <= start || end < 0)
        {
            return this;
        }
        else if(length == 0)
        {
            return append(str);
        }
        else
        {
            if(start == 0)
            {
                for(int x = 1; x <= end -1; x++)
                {
                    currNode = currNode.next;
                }
                firstC = otherCurr;

                otherCurr = s.lastC;    
                otherCurr = currNode.next;
                length = length - end + s.length();
            }
            else
            {
                for(int x = 0; x < start; x++)
                {
                    currNode = currNode.next;
                    if(x == (start - 2))
                    {
                        befNode = currNode;
                    }   
                }
                if(end > length)
                {
                    for(int y = start; y < length -1; y++)
                    {    
                        currNode = currNode.next;
                    }
                    befNode.next = otherCurr;

                    otherCurr = s.lastC;
                    otherCurr.next = null;
                    lastC = otherCurr;
                    length = length - ((length - 1) - start) + s.length();
                }
                else
                {
                    for(int y = start; y < end -1; y++)
                    {    
                        currNode = currNode.next;
                    }
                    befNode.next = otherCurr;
                    otherCurr = s.lastC;
                    lastC = otherCurr;
                    lastC.next = currNode.next;
                    length = length - ((end - 1) - start) + s.length();
                }   
            }
        }
        return this;
    }

    
	// Reverse the characters in the current MyStringBuilder and then
    // return the current MyStringBuilder.
    
	public MyStringBuilder reverse()
	{
        CNode currNode = firstC;
        CNode befNode = null;
        CNode aftNode = null;

        while(currNode != null)
        {
            aftNode = currNode.next;
            currNode.next = befNode;
            befNode = currNode;
            currNode = aftNode;
        }
        firstC = befNode;

        return this;
	}
	
	// Return as a String the substring of characters from index "start" to
    // index "end" - 1 within the current MyStringBuilder
    
	public String substring(int start, int end)
	{
        CNode currNode = firstC;
        char [] c = new char[(end - start)];
        int i = 0;
        if(start < 0 || start > length || end <= start || end < 0)
        {
            return null;
        }
        else if(length == 0)
        {
            return null;
        }
        else if(start == 0)
        {
            for(int x = 1; x <= end; x++)
            {
                c[i] = currNode.data;
                i++;
                currNode = currNode.next;
            }
        }
        else
        {
            for(int x = 0; x < start; x++)
            {
                currNode = currNode.next;
            }
            if(end > length)
            {
                for(int y = start; y < length - 1; y++)
                {
                    c[i] = currNode.data;
                    i++;
                    currNode = currNode.next;
                }
            }
            else
            {
                for(int y = start; y <= end - 1; y++)
                {
                    c[i] = currNode.data;
                    i++;
                    currNode = currNode.next;
                }
            }
        }
        return new String(c);
	}
    
    // Return the entire contents of the current MyStringBuilder as a String
    
	public String toString()
    {
	    char [] c = new char[length];
	    int i = 0;
	    CNode currNode = firstC;
	    while (currNode != null)
	    {
		    c[i] = currNode.data;
		    i++;
		    currNode = currNode.next;
	    }
	    return new String(c);
    }

	// You must use this inner class exactly as specified below.  Note that
	// since it is an inner class, the MyStringBuilder class MAY access the
	// data and next fields directly.
	private class CNode
	{
		private char data;
		private CNode next;

		public CNode(char c)
		{
			data = c;
			next = null;
		}

		public CNode(char c, CNode n)
		{
			data = c;
			next = n;
		}
	}
}
