Eshan Parmar
esp27
esp27@pitt.edu	
All Instructions are functional
No known problems with the design
Control Signals
	ALUOp 		- Provides the operation for the ALU
	IsBranch 	- Signals whether the current instruction was a branch 
	RegWriteA 	- Signals to write to the First Register
	RegWriteB 	- Signals to write to the second register
	Halt 		- Stops the program from continuing to read instructions
	Jump		- Indicates whether the current instruction is a Jal or J Immediated
	MemRead		- Indicates whether the current instruction is able to read from memory
	MemToReg	- Indicates whether the current instruction is taking information from memory to a register
	Put		- Stores the value of $rs into the hex display
	MemWrite	- Indicates whether the current instruction can write to memory
	LiControl	- Signals whether the current instruction is a Load Immediate Instruction
	Unsigned	- Signals whether the current ALU operation is Unsigned
	JR		- High if current instruction is JR
	JAL		- High if current instruction is JAL
	Branch		- Provides a number which represents the type of branch that the current instruction is